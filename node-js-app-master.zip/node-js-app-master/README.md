# AWS Elastic Beanstalk NodeJS application template
##  This is how you do it 
# Money Talks Here For Real
# Cloud Winners Summer Class 2022
